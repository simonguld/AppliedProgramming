#ifndef _CALCULATEEXPONENTIAL_
#define _CALCULATEEXPONENTIAL_

#include <iostream>
#include "ComplexNumber.hpp"

void CalculateExponential(ComplexNumber **A, int nMax, ComplexNumber **res);
/*
void Multiply (ComplexNumber **res ,ComplexNumber **A,ComplexNumber **B,
int ARows , int ACols , int BRows , int BCols );
ComplexNumber** AllocateMemory (int numRows, int numCols);
void FreeMemory (int numRows, ComplexNumber** matrix);
*/
#endif


