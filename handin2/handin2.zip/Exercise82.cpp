#include <iostream>

#include "Exercise82.hpp"



/*
int main()
{

std:: cout << CalcAbs(2) << " " << CalcAbs(-2) << "  " << CalcAbs(3.44) << "   " << CalcAbs(-3.44) << "  " << CalcAbs(0) << "\n";


    return 0;
}
*/